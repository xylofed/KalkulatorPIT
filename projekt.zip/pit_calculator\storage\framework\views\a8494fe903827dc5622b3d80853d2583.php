<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="mb-4">Edycja użytkownika</h2>

    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Imię i nazwisko</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="role" class="form-label">Rola</label>
            <select name="role" id="role" class="form-select" required>
                <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Administrator</option>
                <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>Użytkownik</option>
            </select>
        </div>
        <div class="mb-3">
    <label for="password" class="form-label">Nowe hasło (opcjonalnie)</label>
    <input type="password" name="password" id="password" class="form-control">
</div>

<div class="mb-3">
    <label for="password_confirmation" class="form-label">Potwierdź hasło</label>
    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
</div>

        <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Anuluj</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projekty\Kalkulator PIT\pit_calculator\resources\views/users/edit.blade.php ENDPATH**/ ?>